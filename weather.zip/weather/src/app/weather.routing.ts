import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { CurrentWeatherComponent } from './current-weather/current-weather.component';
import { ForecastComponent } from './forecast/forecast.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ResolveLocationService } from './resolve-location.service';

const WEATHER_ROUTER:Routes = [
	/*{
		path: '', redirectTo:'/current_weather', pathMatch:'full'
	},*/
	{
		path:'current_weather',
		component:CurrentWeatherComponent, resolve:{myWeather:ResolveLocationService}
	},
	{
		path:'forecast',
		component:ForecastComponent
	},
	/*{
		path: "**", 
		component:PagenotfoundComponent
	}*/
];

export const weatherRouting:ModuleWithProviders = RouterModule.forRoot(WEATHER_ROUTER);

	