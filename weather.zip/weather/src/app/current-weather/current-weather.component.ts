import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import 'rxjs/Rx';
import { WeatherService } from '../weather.service';
import { Currentweather } from './currentweather';

@Component({
  selector: 'app-current-weather',
  templateUrl: './current-weather.component.html',
  styleUrls: ['./current-weather.component.css']
})
export class CurrentWeatherComponent implements OnInit {
	myWeather:Currentweather;
	location
	
  	constructor(private weatherServiceObj:WeatherService, private route:ActivatedRoute) { }

  ngOnInit() {
  	this.route.data.subscribe(
  		(data:{myWeather:Currentweather}) => {
  			this.myWeather = data.myWeather;
  		}
  	)
  }

  onSubmit(weatherForm:NgForm){
  	this.weatherServiceObj.anotherCityWeather(weatherForm.value.city).subscribe(
  		(data) => {
  			this.myWeather = new Currentweather(data.name,
		  										data.main.temp,
		  										data.weather[0].icon,
		  										data.weather[0].description,
		  										data.main.temp_max,
		  										data.main.temp_min);
  		}
  	)
  }
 
}
