import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { WeatherService } from './weather.service';

@Injectable({
  providedIn: 'root'
})
export class ResolveLocationService {

  constructor(private weatherServiceObj:WeatherService) { }
  resolve(){
  	return this.weatherServiceObj.localWeather();
  }
}
